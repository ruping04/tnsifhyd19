package com.rupin3.ic;

public class Access {

	public static void main(String[] args) {
		
		
		Normal n1= new Normal();
		System.out.println(n1.ID);
		System.out.println(Normal.Name);
		n1.display();
		System.out.println(Normal.display1());

	}

}
