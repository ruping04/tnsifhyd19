package com.rupin3.ic;

public class Normal {
	
	int ID= 36;
	static String Name= "Rupin";
	
	void display() {
		System.out.println("This is from Aiml");
	}
	
	
	static String display1() {
		
		return "This is from Sri Indu College";
	}

}
