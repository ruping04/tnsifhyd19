package overridelap;
import java.lang.*;

public class BuiltIN {

	public static void main(String[] args) {
		
		int a = 100, b = 200,maxi;

	      maxi = Math.max(a,b);

	      System.out.println("Maximum is = "+maxi); 
		// TODO Auto-generated method stub

	}

}
