package overridelap;
import java.util.Arrays;

public class Builttwo {

	public static void main(String[] args) {
		
		int[] arr = { 40, 30, 20, 70, 80 };

	      Arrays.sort(arr);

	      System.out.println("Sorted Array is = "+Arrays.toString(arr));
		// TODO Auto-generated method stub

	}

}
