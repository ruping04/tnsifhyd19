package overridelap;
import java.awt.*;

public class Buitlt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
