package overridelap;

public class Trained {

	public static void main(String[] args) {
		
			
				Train t=new Train();
				
				t.display();
			}
		
		// TODO Auto-generated method stub

	}

