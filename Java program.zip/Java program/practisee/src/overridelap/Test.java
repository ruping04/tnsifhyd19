package overridelap;

public class Test {
	 void display() {
		System.out.println("HI");;
	}

}

class Train extends Test{
	 void display() {
		System.out.println("HI MY NAME IS RUPIN");;
	}
}


