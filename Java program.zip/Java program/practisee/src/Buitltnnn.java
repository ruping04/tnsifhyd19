import java.awt.*;
public class Buitltnnn {

	
		public void AWTExample()

		  {

		    Frame fr1=new Frame();  

		    Label la = new Label("Welcome to the java graphics");  

		    fr1.add(la);                 

		    fr1.setSize(200, 200);  

		    fr1.setVisible(true);   

		  }

		  public static void main(String args[])

		  {

		    Buitltnnn tw = new Buitltnnn();
		    tw.AWTExample();

		  }
		}
		// TODO Auto-generated method stub

	


