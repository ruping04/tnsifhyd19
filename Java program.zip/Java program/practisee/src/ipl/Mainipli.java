 package ipl;

public class Mainipli {
	public static void main(String args[]) {
		SRH s=new SRH();
		RCB r=new RCB();
		CSK c=new CSK();
		
		s.batsmen();
		r.bowler();
		c.batsmen();
		s.bowler();
	}

}
