package ipl;


public class SRH {
	
	void batsmen() {
		System.out.println("HEAD, KLASSEN, MARKRAM");
	}

	void bowler() {
		System.out.println("CUMMINS, BHUVI, NATTU");
	}
}

 class RCB{
	void batsmen() {
		System.out.println("VIRAT, JACKS, PLESSIS");
		
	}
	
	void bowler() {
		System.out.println("SIRAJ, MAXWELL, KARN");
	}
}
class CSK{
	void batsmen() {
		System.out.println("DHONI, GAIKWAD, JADEJA");
		
	}
	void bowler() {
		System.out.println("DEEPAK, DESHAPANDE, JADEJA");
		
	}
}