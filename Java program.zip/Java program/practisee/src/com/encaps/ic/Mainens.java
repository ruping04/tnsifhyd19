package com.encaps.ic;

public class Mainens {

	public static void main(String args[]) {
		
		Encaps e = new Encaps();
		e.speed=12;
		System.out.println(e.speed);
		e.setName("rupin");
		System.out.println(e.getName());
		e.setNumber(200);
		System.out.println(e.getNumber());
	}
}
