package com.encaps.ic;

public class Encaps {
	public int speed;
	private String name;

	private int number;
	public String getName() {
		return name;
	}
	public void setName(String newname) {
		this.name = newname;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	
	
	

}

