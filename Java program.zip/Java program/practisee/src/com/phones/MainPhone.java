package com.phones;


public class MainPhone {

	public static void main(String[] args) {
		Apple a = new Apple();
		Samsung s = new Samsung();
		Vivo v = new Vivo();
		
		a.display();
		a.storage();
		a.camera();
		s.display();
		s.storage();
		s.camera();
		v.display();
		v.storage();
		v.camera();
		// TODO Auto-generated method stub

	}

}
