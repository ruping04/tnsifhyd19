package com.phones;

public class Apple {
	void display(){
		System.out.println("Has wide and large display with 120hz and Amoled display");
		}
    void storage() { 
    	System.out.println("Has storage upto 128 and 256 GB and extendable ram");
		
	}
    void camera() {
    	System.out.println("Has double and triple cameras with high picture quality and slomo cameras");
    }
}

class Samsung{
	void display() {
		System.out.println("Has 120hz and biggest slim smooth special glass experince");
		
	}
	
	void storage() {
		System.out.println("Storage is upto 128 and 256 GB and extendible ram with efficent data storage");
	}
	
	void camera() {
		System.out.println("Has quad cameras in S24 with high quality with clear picture and high quality");
	}
	
}

class Vivo{
	void display() {
		System.out.println("Has better quality of screen resolutuon with 120hz smooth screen");
	}
	
	void storage() {
		System.out.println("Has storage with 128 and 256GB extendible storage");
	}
	
	void camera() {
		System.out.println("Has good quality of camera with 64mp pixels");
	}
}