package com.mak.ic;

public class TaskNew {
	
	int a=10;
	
	static int b=20;
			
			

	public static void main(String[] args) {
	
		
		int c=30;
		
		TaskNew obj = new TaskNew();
		System.out.println(obj.a);
		System.out.println(TaskNew.b);
		System.out.println(c);
		
		

	}

}
