package ipl.com;

public class Mainphones {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Phones p = new Phones();
		Phone P = new Phone();
		Phoness PP = new Phoness();
		
		p.iphone();
		P.samsung();
		PP.Vivo();

	}

}
