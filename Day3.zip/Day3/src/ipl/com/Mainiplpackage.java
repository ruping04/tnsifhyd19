package ipl.com;

public class Mainiplpackage {

	public static void main(String[] args) {
		
		SRH S = new SRH();
		RCB R = new RCB();
		CSK C = new CSK();
		
		S.batsmen();
		R.Batsmen();
		C.Batsmen();
		// TODO Auto-generated method stub

	}

}
