package ipl.com;

public class SRH {
	
	void batsmen() {
		
		System.out.println("Head, Klassen, Abhishek");
	}
	
	void Bowler() {
		
		System.out.println("Cummins, Bhuvi, Natrajan");
	}

}

class RCB{
	
	void Batsmen() {
		
		System.out.println("Kohli, Du plessiss, Jacks");
	}
	
	void Bowler() {
		
		System.out.println("Ferguson, Jacks, Vyshyak");
	}
}

class CSK{
	
	void Batsmen() {
		System.out.println("Dhoni, Ruturaj, Ali");
	}
	
	void Bowler() {
		
		System.out.println("Pathirana, Deepak, Jadeja");
	}
}