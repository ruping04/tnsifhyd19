package ipl.com;

public class Phones {
	
	void iphone() {
		System.out.println("Iphone 15pro, 14 promax, 15 plus");
	}
	
	void price() {
		
		System.out.println("The price is upto 1 lakh and above ");
	}
	
	void size() {
		
		System.out.println("Has dynamic alignment and good quality if display");
	}
}

class Phone{
	
	void samsung() {

		System.out.println("S24, S23, Galaxy");
		
	}
	
	void price() {
		
		System.out.println("The price is above 1 lakh and also below 1 lakh");
	}
	
	void size() {
		
		System.out.println("It has coolest display and large dispay ever by samsung and AMOLED");
	}
}

class Phoness{
	
	void Vivo() {
		
		System.out.println("Y200, X100");
	}
	
	void price() {
		
		System.out.println("The price of phones is best price where all can afford");
	}
	
	void size() {
		
		System.out.println("It has AMOLED display where it has long display enough");
	}
}

