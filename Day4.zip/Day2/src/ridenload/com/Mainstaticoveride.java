package ridenload.com;

public class Mainstaticoveride {

	public static void main(String[] args) {
		
		Staticoveride.displays();
		overidestat.displays();
		// TODO Auto-generated method stub

	}

}
