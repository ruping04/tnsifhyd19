package ridenload.com;

public class Overloadmain {

	public static void main(String[] args) {
		
		Carload iv = new Carload();
		
		System.out.println(iv.company(10,20,30));
		System.out.println(iv.company(20,30));
		// TODO Auto-generated method stub

	}

}
