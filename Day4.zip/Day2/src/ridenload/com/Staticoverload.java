package ridenload.com;

public class Staticoverload {
	
	static String phone(){
		return "I have number of standard phones in my store";
		
	}

}

class phones extends Staticoverload{
	
	static int phone(int a) {
		return a;
	}
}
