package ridenload.com;

public class Mainoverloadstat {

	public static void main(String[] args) {
		
		System.out.println(phones.phone());
		System.out.println(phones.phone(1000));
		// TODO Auto-generated method stub

	}

}
