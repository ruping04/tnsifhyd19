package encap.com;

public class Encaps2main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		encaps2 en2 = new encaps2();
		
		en2.badminton();
		en2.football();
		System.out.println(en2.getRunning());
		System.out.println(en2.getSwims());

	}

}
