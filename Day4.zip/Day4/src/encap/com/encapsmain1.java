package encap.com;

public class encapsmain1 {

	public static void main(String[] args) {
		
		encaps1 en = new encaps1();
		
		en.display();
		System.out.println(en.name);
		// TODO Auto-generated method stub

	}

}
