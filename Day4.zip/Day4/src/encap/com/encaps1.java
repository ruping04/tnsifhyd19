package encap.com;

public class encaps1 {

	public void display() {
		System.out.println("This is public method where u can access easily");
	}
	
	private void run() {
		
		System.out.println("This cannot be accesed bcoz it is private");
	}
	
	public String name= "Rupin";
	
	private String name2 = "Mallamapalli";
}
