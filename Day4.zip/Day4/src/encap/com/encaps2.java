package encap.com;

public class encaps2 {

	public String running= "Usian bolt";
	
	private String swims = "glen philips";
	
	public void badminton() {
		
		System.out.println("P.V Sindhu is the player who got silver medal");
	}
	
	public void football() {
		
		System.out.println("Messi got his first world cup in FIFA representing Argentina team");
	}

	public String getRunning() {
		return running;
	}

	public void setRunning(String running) {
		this.running = running;
	}

	public String getSwims() {
		return swims;
	}

	public void setSwims(String swims) {
		this.swims = swims;
	}
}
