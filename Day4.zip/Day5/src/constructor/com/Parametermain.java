package constructor.com;

public class Parametermain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Parameterizedcons pc = new Parameterizedcons("Rupin",6,79,"Hyderabad");
		
		pc.display();

	}

}
