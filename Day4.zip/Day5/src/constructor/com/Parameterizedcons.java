package constructor.com;
public class Parameterizedcons {
	
	public String Names;
	private int Height ;
	private int weight ;
	private String State; 
	
	public Parameterizedcons(String Names, int Height, int weight,  String State ) {
		
		this.Names = Names;
		this.Height= Height;
		this.weight = weight;
		this.State = State;
		
		
	}
	
	void display() {
		
		System.out.print(Names+" "+Height+" "+weight+" "+State+" ");
	}

}
