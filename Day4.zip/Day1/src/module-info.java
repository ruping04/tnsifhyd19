/**
 * 
 */
/**
 * 
 */
module Day1 {
}