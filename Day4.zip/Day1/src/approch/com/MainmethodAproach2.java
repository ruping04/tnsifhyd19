package approch.com;

public class MainmethodAproach2 {

	public static void main(String[] args) {
		
		System.out.println("Showing the company cars with names");
		Approach2 A = new Approach2(); 
		System.out.println(A.Company);
		A.display();
		System.out.println(Approach2.Company2);
		Approach2.display2();
		// TODO Auto-generated method stub

	}

}
