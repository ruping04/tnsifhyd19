package approch.com;

public class Approach2 {
	
	String Company ="KIA";
	
	void display() {
		System.out.println("KIA seltos");
	}
	
	static String Company2 ="Hyundai";
	
	static void display2() {
		
		System.out.println("Hyudai CRETA");
	}
	

	

}
