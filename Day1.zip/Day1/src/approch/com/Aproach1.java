package approch.com;

public class Aproach1 {
	
	 String batsmen= "head";
	 
	 static String Bowler="bhuvi";
	 
	 void Batsmen() {
		 System.out.println("Iam batsmen of SRH");
		 
	 }
	 
	 static void Bowler() {
		 System.out.println("Iam Bowler of SRH");
	 }

	public static void main(String[] args) {
		
		System.out.println("This is methods variables of SRH");
		Aproach1 SRH = new Aproach1();
		System.out.println(SRH.batsmen);
		SRH.Batsmen();
		System.out.println(Aproach1.Bowler);
		Aproach1.Bowler();
		
		// TODO Auto-generated method stub

	}

}
