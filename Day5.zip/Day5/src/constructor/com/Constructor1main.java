package constructor.com;

public class Constructor1main {

	public static void main(String[] args) {
		
		Constructor1 cn = new Constructor1();
		cn.run();
		
		// TODO Auto-generated method stub

	}

}
