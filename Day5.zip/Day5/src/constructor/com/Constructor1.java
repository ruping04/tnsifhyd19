package constructor.com;

public class Constructor1 {
	
	public String name;
	private int Age;
	private String Add;
	private String Lastname;
	
	public Constructor1() {
		
		name = "Rupin";
		
		Age = 20;
		
		Add = "Hyderabad";
		
		Lastname = "Mallamapalli";
	}
	
	public void run() {
		
		if(name == "Rupin" && Age == 20 && Add == "Hyderabad" && Lastname== "Mallam" ){
		
		System.out.println("Yes");
		}
		
		else {
			
			System.out.println("No");
		}
			
	}
	

}
