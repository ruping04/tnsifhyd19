package com.project.main.service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.project.main.entity.Admin;
import com.project.main.repository.AdminRepository;


@Service
public class AdminServiceImpl implements AdminService{

	@Autowired
	private AdminRepository adminRepository;

	@Override
	public Admin saveAdmin(Admin admin) {
		// TODO Auto-generated method stub
		return adminRepository.save(admin);
	}

	@Override
	public List<Admin> fetchadminList() {
		// TODO Auto-generated method stub
		return adminRepository.findAll();
	}

	@Override
	public Admin fetchAdminById(Long adminid) {
		// TODO Auto-generated method stub
		return adminRepository.findById(adminid).get();
	}

	@Override
	public void deleteAdminById(Long adminid) {
		// TODO Auto-generated method stub
		 adminRepository.deleteById(adminid);
		
	}

	@Override
	public Admin updateadmin(Long adminid, Admin admin) {
		// TODO Auto-generated method stub
		Admin adDB = adminRepository.findById(adminid).get();
	
		if(Objects.nonNull(admin.getAdminname()) &&
			       !"".equalsIgnoreCase(admin.getAdminname())) {
			           adDB.setAdminname(admin.getAdminname());
		}
		
		if(Objects.nonNull(admin.getAdminpassword()) &&
	               !"".equalsIgnoreCase(admin.getAdminpassword())) {
	           adDB.setAdminpassword(admin.getAdminpassword());
	       }
		
		 
		
		return adminRepository.save(adDB);
}
}
