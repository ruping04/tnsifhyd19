package com.project.main.service;

import java.util.List;

import com.project.main.entity.Admin;

public interface AdminService {

	Admin saveAdmin(Admin admin);

	List<Admin> fetchadminList();

	Admin fetchAdminById(Long adminid);

	void deleteAdminById(Long adminid);

	Admin updateadmin(Long adminid, Admin admin);

	

}