package ridenload.com;

public class Instanceoveride {
	
	void display() {
		System.out.println("Hi am Rupin");
		
	}
		
}
class overide extends Instanceoveride{
	void display() {
		System.out.println("My name is Rupin From AIML");
	}
}