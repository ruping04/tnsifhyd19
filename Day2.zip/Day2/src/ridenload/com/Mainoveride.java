package ridenload.com;

public class Mainoveride {

	public static void main(String[] args) {
		
		overide io = new overide();
		io.display();
		// TODO Auto-generated method stub

	}

}
