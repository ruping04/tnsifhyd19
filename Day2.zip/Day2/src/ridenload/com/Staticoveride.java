package ridenload.com;

public class Staticoveride {
	
	static void displays() {
		System.out.println("Static method is playing here");
	}

}

class overidestat extends Staticoveride{
	
	static void displays() {
		System.out.println("Static method cannot be overidden and cannot perform the method.");
	}
}
