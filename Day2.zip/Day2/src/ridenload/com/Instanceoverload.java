package ridenload.com;

public class Instanceoverload {
	
	 int company(int a, int b, int c) {
		return a+b+c;
	}

}

class Carload extends Instanceoverload{
	
 int company(int a, int b) {
		return a*b;
	}
}
